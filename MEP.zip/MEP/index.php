<?php
$error = "";
if (isset($_POST['submit'])) {
    if (!empty($_POST ['username']) && !empty($_POST ['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $user = "dzcole";
        $pass = "version1";
        if ($username == $user && $password == $pass) {
            session_start();
            $_SESSION['ingelogd'] = true;
            header ("Location: ingelogd.php");
        }
    }
} else {
    $error = "Username & password zijn verplicht";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title></title>
</head>
<body>

<h1>Login form zonder DB</h1>
<form method="POST">
    <?php echo $error; ?><br>
    <label>Username:</label><br><input type="text" name="username"/><br>
    <label>Password:</label><br><input type="password" name="password"/><br>
    <input type="submit" name="submit" value="Inloggen" />
</form>


</body>
</html>