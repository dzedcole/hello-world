/* --------------- T E S T I N G --------------- */

function testFadeIn() {
	document.getElementById("test1").style.animation = "testFadeIn ease 0.2s";
	document.getElementById("test1").style.animationIterationCount = "1";
	document.getElementById("test1").style.animationFillMode = "forwards"
}


/* --------------- P R O J E C T --------------- */
function play() {
	var audio = new Audio();
	audio.src = "../sounds/succes.WAV";
	audio.volume = "0.5"
	audio.play();
  }
  function start() {
  }

/* --------------- V O D --------------- */

var i = 0;
function selectFire() {
	if (document.getElementById("fire-symbol").style.borderColor=="black") {

document.getElementById("fire-symbol").style.borderColor = "orange";
document.getElementById("fire-symbol").style.borderWidth = "5px";

    document.getElementById("fire-text").style.visibility = "visible";
	document.getElementById("fire-text").innerHTML = ++i;
	
	
	}
	else {
		document.getElementById("fire-symbol").style.borderColor = "black";
		document.getElementById("fire-symbol").style.borderWidth = "3px";
		document.getElementById("fire-text").innerHTML = "";
		document.getElementById("fire-text").style.visibility = "hidden";
	}
}



function selectWater() {
	if (document.getElementById("water-symbol").style.borderColor=="black"){
	
document.getElementById("water-symbol").style.borderColor = "orange";
document.getElementById("water-symbol").style.borderWidth = "5px";


    document.getElementById("water-text").style.visibility = "visible";
	document.getElementById("water-text").innerHTML = ++i;

    }
else {
	document.getElementById("water-symbol").style.borderColor = "black";
	document.getElementById("water-symbol").style.borderWidth = "3px";
	document.getElementById("water-text").innerHTML = "";
	document.getElementById("water-text").style.visibility = "hidden";
}
	}


function selectAir() {
	if (document.getElementById("air-symbol").style.borderColor=="black") {
	
document.getElementById("air-symbol").style.borderColor = "orange";
document.getElementById("air-symbol").style.borderWidth = "5px";

    document.getElementById("air-text").style.visibility = "visible";
	document.getElementById("air-text").innerHTML = ++i;
	}
	else {
		document.getElementById("air-symbol").style.borderColor = "black";
		document.getElementById("air-symbol").style.borderWidth = "3px";
		document.getElementById("air-text").innerHTML = "";
		document.getElementById("air-text").style.visibility = "hidden";
	}
		}



function selectEarth() {

if (document.getElementById("earth-symbol").style.borderColor=="black"){
			
document.getElementById("earth-symbol").style.borderColor = "orange";
document.getElementById("earth-symbol").style.borderWidth = "5px";	

    document.getElementById("earth-text").style.visibility = "visible";
	document.getElementById("earth-text").innerHTML = ++i;
    }
else {
	document.getElementById("earth-symbol").style.borderColor = "black";
	document.getElementById("earth-symbol").style.borderWidth = "3px";
    edocument.getElementById("earth-text").innerHTML = "";
	document.getElementById("earth-text").style.visibility = "hidden";
}
}



function reset() {
	i = 0;

	document.getElementById("fire-symbol").style.borderColor = "black";
	document.getElementById("fire-symbol").style.borderWidth = "3px";
	document.getElementById("fire-text").innerHTML = "";
	document.getElementById("fire-text").style.visibility = "hidden";

	document.getElementById("water-symbol").style.borderColor = "black";
	document.getElementById("water-symbol").style.borderWidth = "3px";
	document.getElementById("water-text").innerHTML = "";
	document.getElementById("water-text").style.visibility = "hidden";

	document.getElementById("air-symbol").style.borderColor = "black";
	document.getElementById("air-symbol").style.borderWidth = "3px";
	document.getElementById("air-text").innerHTML = "";
	document.getElementById("air-text").style.visibility = "hidden";

	document.getElementById("earth-symbol").style.borderColor = "black";
	document.getElementById("earth-symbol").style.borderWidth = "3px";
    document.getElementById("earth-text").innerHTML = "";
	document.getElementById("earth-text").style.visibility = "hidden";

}


/* --------------- I X --------------- */



/* --------------- R E F O R G E  O P E N  &  C L O S E  --------------- */
function closeReforgeStats() {

	document.getElementById("reforge-menu-bg").style.visibility = "hidden";

	document.getElementById("reforge-stats").style.animation = "fadeOutReforgeAnimation ease 1s";
	document.getElementById("reforge-stats").style.animationIterationCount = "1";
	document.getElementById("reforge-stats").style.animationFillMode = "forwards";
	
}
var health = 0;
var defense = 0;
var strength = 0;
var speed = 0;
var critChance = 0;
var critDamage = 0;
var inteligence = 0;
var attackSpeed = 0;


function openReforgeStats() {
	document.getElementById("reforge-stats").style.visibility = "visible";
	document.getElementById("health").innerHTML = health;
	document.getElementById("defense").innerHTML = defense;
	document.getElementById("strength").innerHTML = strength;
	document.getElementById("speed").innerHTML = speed;
	document.getElementById("critChance").innerHTML = critChance;
	document.getElementById("critDamage").innerHTML = critDamage;
	document.getElementById("inteligence").innerHTML = inteligence;
	document.getElementById("attackSpeed").innerHTML = attackSpeed;

	document.getElementById("reforge-stats").style.animation = "fadeInReforgeAnimation ease 0.4s";
	document.getElementById("reforge-stats").style.animationIterationCount = "1";
	document.getElementById("reforge-stats").style.animationFillMode = "fowards";
	document.getElementById("reforge-menu-bg").style.visibility = "visible";
	document.getElementById("reforges").style.zIndex = "1";
	document.getElementById("reforge-stats").style.zIndex = "2";
}
function openReforgeStatsFierce() {
	document.getElementById("reforge-name").innerHTML = "Fierce"; 
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}

function openReforgeStatsMythic() {
	document.getElementById("reforge-name").innerHTML= "Mythic";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsWise() {
	document.getElementById("reforge-name").innerHTML= "Wise";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsSmart() {
	document.getElementById("reforge-name").innerHTML= "Smart";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsGodly() {
	document.getElementById("reforge-name").innerHTML= "Godly";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsForceful() {
	document.getElementById("reforge-name").innerHTML= "Forceful";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsHurtful() {
	document.getElementById("reforge-name").innerHTML= "Hurtful";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsSuperior() {
	document.getElementById("reforge-name").innerHTML= "Superior";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsStrong() {
	document.getElementById("reforge-name").innerHTML= "Strong";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsLight() {
	document.getElementById("reforge-name").innerHTML= "Light";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsHeavy() {
	document.getElementById("reforge-name").innerHTML= "Heavy";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsDemonic() {
	document.getElementById("reforge-name").innerHTML= "Demonic";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsUnpleasant() {
	document.getElementById("reforge-name").innerHTML= "Unpleasant";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsClean() {
	document.getElementById("reforge-name").innerHTML= "Clean";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsKeen() {
	document.getElementById("reforge-name").innerHTML= "Keen";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsTitanic() {
	document.getElementById("reforge-name").innerHTML= "Titanic";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsZealous() {
	document.getElementById("reforge-name").innerHTML= "Zealous";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsPure() {
	document.getElementById("reforge-name").innerHTML= "Pure";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}

function openReforgeStatsGentle() {
	document.getElementById("reforge-name").innerHTML= "Gentle";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsSpicy() {
	document.getElementById("reforge-name").innerHTML= "Spicy";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsFast() {
	document.getElementById("reforge-name").innerHTML= "Fast";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsRich() {
	document.getElementById("reforge-name").innerHTML= "Rich";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsFair() {
	document.getElementById("reforge-name").innerHTML= "Fair";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsLegendary() {
	document.getElementById("reforge-name").innerHTML= "Legendary";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsHeroic() {
	document.getElementById("reforge-name").innerHTML= "Heroic";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsEpic() {
	document.getElementById("reforge-name").innerHTML= "Epic";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsOdd() {
	document.getElementById("reforge-name").innerHTML= "Odd";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}

function openReforgeStatsBizarre() {
	document.getElementById("reforge-name").innerHTML= "Bizarre";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsOminous() {
	document.getElementById("reforge-name").innerHTML= "Ominous";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsSimple() {
	document.getElementById("reforge-name").innerHTML= "Simple";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsStrange() {
	document.getElementById("reforge-name").innerHTML= "Strange";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsPleasant() {
	document.getElementById("reforge-name").innerHTML= "Pleasant";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsShiny() {
	document.getElementById("reforge-name").innerHTML= "Shiny";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsVivid() {
	document.getElementById("reforge-name").innerHTML= "Vivid";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsPretty() {
	document.getElementById("reforge-name").innerHTML= "Pretty";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsItchy() {
	document.getElementById("reforge-name").innerHTML= "Itchy";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsFine() {
	document.getElementById("reforge-name").innerHTML= "Fine";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsNeat() {
	document.getElementById("reforge-name").innerHTML= "Neat";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsHasty() {
	document.getElementById("reforge-name").innerHTML= "Hasty";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsGrand() {
	document.getElementById("reforge-name").innerHTML= "Grand";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsRapid() {
	document.getElementById("reforge-name").innerHTML= "Rapid";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsDeadly() {
	document.getElementById("reforge-name").innerHTML= "Deadly";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsUnreal() {
	document.getElementById("reforge-name").innerHTML= "Unreal";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsSpiked() {
	document.getElementById("reforge-name").innerHTML= "Spiked";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsRenowned() {
	document.getElementById("reforge-name").innerHTML= "Renowned";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsNecrotic() {
	document.getElementById("reforge-name").innerHTML= "Necrotic";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsGiant() {
	document.getElementById("reforge-name").innerHTML= "Giant";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsReinforced() {
	document.getElementById("reforge-name").innerHTML= "Reinforced";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsEmpowered() {
	document.getElementById("reforge-name").innerHTML= "Empowered";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}
function openReforgeStatsFabled() {
	document.getElementById("reforge-name").innerHTML= "Fabled";
	health = 0; defense = 0; strength = 0; speed = 0; critChance = 0;
	critDamage = 0; inteligence = 0; attackSpeed = 0;
}